﻿
namespace stok
{
	partial class frmMüşteriListele
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.label5 = new System.Windows.Forms.Label();
			this.txtAdres = new System.Windows.Forms.TextBox();
			this.btnGüncelle = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.txtEMail = new System.Windows.Forms.TextBox();
			this.txtTelefon = new System.Windows.Forms.TextBox();
			this.txtSoyad = new System.Windows.Forms.TextBox();
			this.txtAd = new System.Windows.Forms.TextBox();
			this.btnSil = new System.Windows.Forms.Button();
			this.txtTelArama = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// dataGridView1
			// 
			this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Location = new System.Drawing.Point(175, 67);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.RowHeadersWidth = 42;
			this.dataGridView1.Size = new System.Drawing.Size(501, 282);
			this.dataGridView1.TabIndex = 0;
			this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(7, 205);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(34, 13);
			this.label5.TabIndex = 15;
			this.label5.Text = "Adres";
			// 
			// txtAdres
			// 
			this.txtAdres.Location = new System.Drawing.Point(69, 205);
			this.txtAdres.Name = "txtAdres";
			this.txtAdres.Size = new System.Drawing.Size(100, 20);
			this.txtAdres.TabIndex = 14;
			// 
			// btnGüncelle
			// 
			this.btnGüncelle.Location = new System.Drawing.Point(78, 290);
			this.btnGüncelle.Name = "btnGüncelle";
			this.btnGüncelle.Size = new System.Drawing.Size(80, 35);
			this.btnGüncelle.TabIndex = 13;
			this.btnGüncelle.Text = "Güncelle";
			this.btnGüncelle.UseVisualStyleBackColor = true;
			this.btnGüncelle.Click += new System.EventHandler(this.btnGüncelle_Click);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(7, 244);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(36, 13);
			this.label4.TabIndex = 9;
			this.label4.Text = "E-Mail";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(7, 166);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(43, 13);
			this.label3.TabIndex = 10;
			this.label3.Text = "Telefon";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(7, 127);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(37, 13);
			this.label2.TabIndex = 11;
			this.label2.Text = "Soyad";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(7, 88);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(20, 13);
			this.label1.TabIndex = 12;
			this.label1.Text = "Ad";
			// 
			// txtEMail
			// 
			this.txtEMail.Location = new System.Drawing.Point(69, 244);
			this.txtEMail.Name = "txtEMail";
			this.txtEMail.Size = new System.Drawing.Size(100, 20);
			this.txtEMail.TabIndex = 5;
			// 
			// txtTelefon
			// 
			this.txtTelefon.Location = new System.Drawing.Point(69, 166);
			this.txtTelefon.Name = "txtTelefon";
			this.txtTelefon.Size = new System.Drawing.Size(100, 20);
			this.txtTelefon.TabIndex = 6;
			// 
			// txtSoyad
			// 
			this.txtSoyad.Location = new System.Drawing.Point(69, 127);
			this.txtSoyad.Name = "txtSoyad";
			this.txtSoyad.Size = new System.Drawing.Size(100, 20);
			this.txtSoyad.TabIndex = 7;
			// 
			// txtAd
			// 
			this.txtAd.Location = new System.Drawing.Point(69, 88);
			this.txtAd.Name = "txtAd";
			this.txtAd.Size = new System.Drawing.Size(100, 20);
			this.txtAd.TabIndex = 8;
			// 
			// btnSil
			// 
			this.btnSil.Location = new System.Drawing.Point(682, 66);
			this.btnSil.Name = "btnSil";
			this.btnSil.Size = new System.Drawing.Size(80, 35);
			this.btnSil.TabIndex = 13;
			this.btnSil.Text = "Sil";
			this.btnSil.UseVisualStyleBackColor = true;
			this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
			// 
			// txtTelArama
			// 
			this.txtTelArama.Location = new System.Drawing.Point(407, 31);
			this.txtTelArama.Name = "txtTelArama";
			this.txtTelArama.Size = new System.Drawing.Size(100, 20);
			this.txtTelArama.TabIndex = 16;
			this.txtTelArama.TextChanged += new System.EventHandler(this.txtTelArama_TextChanged);
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(325, 34);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(76, 13);
			this.label6.TabIndex = 0;
			this.label6.Text = "Telefon Ara";
			// 
			// frmMüşteriListele
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Yellow;
			this.ClientSize = new System.Drawing.Size(762, 446);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.txtTelArama);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.txtAdres);
			this.Controls.Add(this.btnSil);
			this.Controls.Add(this.btnGüncelle);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtEMail);
			this.Controls.Add(this.txtTelefon);
			this.Controls.Add(this.txtSoyad);
			this.Controls.Add(this.txtAd);
			this.Controls.Add(this.dataGridView1);
			this.Name = "frmMüşteriListele";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Müşteri Listeleme Sayfası";
			this.Load += new System.EventHandler(this.frmMüşteriListele_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtAdres;
		private System.Windows.Forms.Button btnGüncelle;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtEMail;
		private System.Windows.Forms.TextBox txtTelefon;
		private System.Windows.Forms.TextBox txtSoyad;
		private System.Windows.Forms.TextBox txtAd;
		private System.Windows.Forms.Button btnSil;
		private System.Windows.Forms.TextBox txtTelArama;
		private System.Windows.Forms.Label label6;
	}
}