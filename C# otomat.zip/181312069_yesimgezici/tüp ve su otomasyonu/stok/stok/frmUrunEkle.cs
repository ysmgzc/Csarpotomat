﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace stok
{
	public partial class frmUrunEkle : Form
	{
		public frmUrunEkle()
		{
			InitializeComponent();
		}
		SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-C1PR6G1\\SQLEXPRESS;Initial Catalog=stokk_takipp;Integrated Security=True");
		
		bool durum;

		private bool barkodkontrol()
		{
			durum = true;
			baglanti.Open();
			SqlCommand komut = new SqlCommand("select *from urun", baglanti);
			SqlDataReader read = komut.ExecuteReader();
			while (read.Read())
			{//x kategorısıne baglı aynı marka varsa onu engelle
				if (txtBarkodNo.Text == read["barkodno"].ToString() || txtBarkodNo.Text == " ")
				{
					durum = false;
					break;
				}
			
			}
				baglanti.Close();
			return durum;
		}

		private void kategorigetir()
		{
			baglanti.Open();
			SqlCommand komut = new SqlCommand("select *from kategoribilgileri ", baglanti);
			SqlDataReader read = komut.ExecuteReader();
			while (read.Read())
			{
				comboKategori.Items.Add(read["kategori"].ToString());


			}
			baglanti.Close();

		}
		private void frmUrunEkle_Load(object sender, EventArgs e)
		{
			kategorigetir();
		}

		private void comboKategori_SelectedIndexChanged(object sender, EventArgs e)
		{
			comboMarka.Items.Clear();//onceki işlemler silinsin
			comboMarka.Text = "";//text i de temizlesin
			baglanti.Open();
			SqlCommand komut = new SqlCommand("select *from markabilgileri where kategori='"+comboKategori.SelectedItem+"' ", baglanti);
			SqlDataReader read = komut.ExecuteReader();
			while (read.Read())
			{
				comboMarka.Items.Add(read["marka"].ToString());


			}
			baglanti.Close();

		}

		private void btnYeniEkle_Click(object sender, EventArgs e)
		{
			
			if (barkodkontrol())
			{
				
				baglanti.Open();
				SqlCommand komut = new SqlCommand("insert into urun(barkodno,kategori,marka,urunadi,miktari,alisfiyati,satisfiyati,tarih) values(@barkodno,@kategori,@marka,@urunadi,@miktari,@alisfiyati,@satisfiyati,@tarih) ", baglanti);
				komut.Parameters.AddWithValue("@barkodno", txtBarkodNo.Text);
				komut.Parameters.AddWithValue("@kategori",comboKategori.Text);
				komut.Parameters.AddWithValue("@marka", comboMarka.Text);
				komut.Parameters.AddWithValue("@urunadi", txtUrunAdi.Text);
				komut.Parameters.AddWithValue("@miktari", int.Parse(txtMiktar.Text));
				komut.Parameters.AddWithValue("@alisfiyati", double.Parse(txtAlisFiyati.Text));
				komut.Parameters.AddWithValue("@satisfiyati", double.Parse(txtSatisFiyati.Text));
				komut.Parameters.AddWithValue("@tarih", DateTime.Now.ToString());

				komut.ExecuteNonQuery();
				baglanti.Close();
				
				MessageBox.Show("Ürün Eklendi");
			}

			else
			{
				MessageBox.Show("Böyle bir barkodno bulunmaktadır.", "Uyarı!");
			}
			comboMarka.Items.Clear();
			foreach (Control item in groupBox1.Controls)
			{
				if (item is TextBox)
				{
					item.Text = "";
				}
				if (item is ComboBox)
				{
					item.Text = "";
				}
			}
		}

		private void BarkodNotxt_TextChanged(object sender, EventArgs e)
		{
			if(BarkodNotxt.Text=="")
			{
				lblMiktarı.Text = "";
				foreach(Control item in groupBox2.Controls)
				{
					if(item is TextBox)
					{
						item.Text = "";
					}

				}
			}

			baglanti.Open();
			SqlCommand komut = new SqlCommand("select *from urun where barkodno like '"+BarkodNotxt.Text+"'",baglanti);
			SqlDataReader read = komut.ExecuteReader();
			while(read.Read())
			{
				Kategoritxt.Text = read["kategori"].ToString();
				Markatxt.Text = read["marka"].ToString();
				Urunaditxt.Text = read["urunadi"].ToString();
				lblMiktarı.Text = read["miktari"].ToString();
				AlisFiyatitxt.Text = read["alisfiyati"].ToString();
				SatisFiyatitxt.Text = read["satisfiyati"].ToString();
				

			}
			baglanti.Close();
		}

		private void btnVarOlanaEkle_Click(object sender, EventArgs e)
		{
			baglanti.Open();
			SqlCommand komut = new SqlCommand("update urun set miktari=miktari+'"+int.Parse(Miktaritxt.Text)+"'where barkodno='"+BarkodNotxt.Text+"'",baglanti);
			komut.ExecuteNonQuery();
			baglanti.Close();
			//temizler
			foreach (Control item in groupBox2.Controls)
			{
				if (item is TextBox)
				{
					item.Text = "";
				}

			}
			MessageBox.Show("Var Olan Urune Ekleme Yapıldı"); //ekrana cıkacak yazı
		}

		private void comboMarka_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void txtBarkodNo_TextChanged(object sender, EventArgs e)
		{

		}
	}
}
