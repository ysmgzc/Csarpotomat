﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stok
{
	public partial class SatısSayfası : Form
	{
		public SatısSayfası()
		{
			InitializeComponent();
		}

		SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-C1PR6G1\\SQLEXPRESS;Initial Catalog=stokk_takipp;Integrated Security=True");
		DataSet daset = new DataSet();
		private void sepetlistele()
		{
			baglanti.Open();
			SqlDataAdapter adtr = new SqlDataAdapter("select *from sepet", baglanti);
			adtr.Fill(daset, "sepet");
			dataGridView1.DataSource = daset.Tables["sepet"];
			//ilk 2 sütunu gizlemek için
			//dataGridView1.Columns[0].Visible = false;
			//dataGridView1.Columns[1].Visible = false;

			baglanti.Close();

		}
		private void btnMusteriEkle_Click(object sender, EventArgs e)
		{
			frmMusteriEkle ekle = new frmMusteriEkle();
			ekle.ShowDialog();

		}

		private void btnMusteriListele_Click(object sender, EventArgs e)
		{
			frmMüşteriListele listele = new frmMüşteriListele();
			listele.ShowDialog();
		}

		private void btnUrunEkle_Click(object sender, EventArgs e)
		{
			frmUrunEkle ekle = new frmUrunEkle();
			ekle.ShowDialog();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			frmKategori kategori = new frmKategori();
			kategori.ShowDialog();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			frmMarka marka = new frmMarka();
			marka.ShowDialog();
		}

		private void btnUrunListele_Click(object sender, EventArgs e)
		{
			frmUrunListele listele = new frmUrunListele();
			listele.ShowDialog();

		}
		private void hesapla()
		{
			try
			{
				baglanti.Open();
				SqlCommand komut = new SqlCommand("select sum(toplamfiyati) from sepet", baglanti);
				lblGenelToplam.Text = komut.ExecuteScalar() + " TL";
				baglanti.Close();

			}
			catch (Exception)
			{

				;
			}
		}

		private void SatısSayfası_Load(object sender, EventArgs e)
		{
			sepetlistele();
			hesapla();
		}

		private void txtTelefon_TextChanged(object sender, EventArgs e)
		{
			if (txtTelefon.Text == "")
			{
				txtAdSoyad.Text = "";

			}
			baglanti.Open();
			SqlCommand komut = new SqlCommand("select *from müşteri where telefon like '" + txtTelefon.Text + "'", baglanti);
			SqlDataReader read = komut.ExecuteReader();
			while (read.Read())
			{
				txtAdSoyad.Text = read["adsoyad"].ToString();

			}
			baglanti.Close();
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
			if (txtBarkodNo.Text == "*")
			{
				txtBarkodNo.Text = "";
			}
			Temizle();
			baglanti.Open();
			SqlCommand komut = new SqlCommand("select *from urun where barkodno like '" + txtBarkodNo.Text + "'", baglanti);
			SqlDataReader read = komut.ExecuteReader();
			while (read.Read())
			{
				txtUrunAdı.Text = read["urunadi"].ToString();
				txtSatisFiyati.Text = read["satisfiyati"].ToString();

			}
			baglanti.Close();
		}
		private void Temizle()
		{
			if (txtBarkodNo.Text == "")
			{
				foreach (Control item in groupBox2.Controls)
				{
					if (item is TextBox)
					{
						if (item != txtUrunMiktari)
						{
							item.Text = "";
						}
					}

				}
			}
		}
		private void frmSatis_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Multiply)
			{
				txtUrunMiktari.Text = txtBarkodNo.Text.Replace("*", "");
				txtBarkodNo.Text = "";
			}
		}
		bool durum;
		private void barkodkontrol()
		{
			durum = true;
			baglanti.Open();
			SqlCommand komut = new SqlCommand("select *from sepet", baglanti);
			SqlDataReader read = komut.ExecuteReader();
			while (read.Read())
			{
				if (txtBarkodNo.Text == read["barkodno"].ToString())
				{
					durum = false;
				}
			}
			baglanti.Close();
		}
		int secim;
		private void urunmiktarikontrol()
		{
			secim = 1;
			baglanti.Open();
			SqlCommand komut = new SqlCommand("select *from urun", baglanti);
			SqlDataReader read = komut.ExecuteReader();
			while (read.Read())
			{
				if (txtBarkodNo.Text == read["barkodno"].ToString())
				{
					int miktar = int.Parse(read["miktari"].ToString());
					if (miktar <= 0 || miktar < int.Parse(txtUrunMiktari.Text))
					{
						secim = 0;
					}

				}
			}
			baglanti.Close();

		}
		private void btnEkle_Click(object sender, EventArgs e)
		{
			urunmiktarikontrol();
			if (secim == 1)
			{


				barkodkontrol();


				if (durum == true)
				{
					baglanti.Open();
					SqlCommand komut = new SqlCommand("insert into sepet(adsoyad,telefon,barkodno,urunadi,miktari,satisfiyati,toplamfiyati,tarih) values(@adsoyad,@telefon,@barkodno,@urunadi,@miktari,@satisfiyati,@toplamfiyati,@tarih) ", baglanti);
					komut.Parameters.AddWithValue("@adsoyad", txtAdSoyad.Text);
					komut.Parameters.AddWithValue("@telefon", txtTelefon.Text);
					komut.Parameters.AddWithValue("@barkodno", txtBarkodNo.Text);
					komut.Parameters.AddWithValue("@urunadi", txtUrunAdı.Text);
					komut.Parameters.AddWithValue("@miktari", int.Parse(txtUrunMiktari.Text));
					komut.Parameters.AddWithValue("@satisfiyati", double.Parse(txtSatisFiyati.Text));
					komut.Parameters.AddWithValue("@toplamfiyati", double.Parse(txtToplamFiyat.Text));
					komut.Parameters.AddWithValue("@tarih", DateTime.Now.ToString());
					komut.ExecuteNonQuery();
					baglanti.Close();
				}
				else
				{
					baglanti.Open();
					SqlCommand komut2 = new SqlCommand("update sepet set miktari=miktari+'" + int.Parse(txtUrunMiktari.Text) + "' where barkodno='" + txtBarkodNo.Text + "'", baglanti);
					komut2.ExecuteNonQuery();

					SqlCommand komut3 = new SqlCommand("update sepet set toplamfiyati=miktari*satisfiyati where barkodno='" + txtBarkodNo.Text + "'", baglanti);

					komut3.ExecuteNonQuery();

					baglanti.Close();
				}
			}
			else if (secim == 0)
			{
				MessageBox.Show("Yetersiz stok miktarı");
			}
			txtUrunMiktari.Text = "1";
			daset.Tables["sepet"].Clear();
			sepetlistele();
			hesapla();
			foreach (Control item in groupBox2.Controls)
			{
				if (item is TextBox)
				{
					if (item != txtUrunMiktari)
					{
						item.Text = "";
					}
				}

			}

		}

		private void txtUrunMiktari_TextChanged(object sender, EventArgs e)
		{
			try
			{
				txtToplamFiyat.Text = (double.Parse(txtUrunMiktari.Text) * double.Parse(txtSatisFiyati.Text)).ToString();
			}
			catch (Exception)
			{

				;
			}
		}
		private void txtSatisFiyati_TextChanged(object sender, EventArgs e)
		{
			try
			{
				txtToplamFiyat.Text = (double.Parse(txtUrunMiktari.Text) * double.Parse(txtSatisFiyati.Text)).ToString();
			}
			catch (Exception)
			{

				;
			}
		}

		private void btnSil_Click(object sender, EventArgs e)
		{
			baglanti.Open();
			SqlCommand komut = new SqlCommand("delete from sepet where barkodno='" + dataGridView1.CurrentRow.Cells["barkodno"].Value.ToString() + "'", baglanti);
			komut.ExecuteNonQuery();
			baglanti.Close();
			MessageBox.Show("Ürün sepetten çıkarıldı");
			daset.Tables["sepet"].Clear();
			sepetlistele();
			hesapla();
		}

		private void btnSatisİptal_Click(object sender, EventArgs e)
		{
			baglanti.Open();
			SqlCommand komut = new SqlCommand("delete from sepet", baglanti);
			komut.ExecuteNonQuery();
			baglanti.Close();
			MessageBox.Show("Ürünler sepetten çıkarıldı");
			daset.Tables["sepet"].Clear();
			sepetlistele();
			hesapla();
		}

		private void btnSatislariListele_Click(object sender, EventArgs e)
		{
			{
				{

				frmSatışListele	listele = new frmSatışListele();
					listele.ShowDialog();

				}
			}


		}

		private void btnSatisYap_Click(object sender, EventArgs e)
		{
			for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
			{
				baglanti.Open();
				SqlCommand komut = new SqlCommand("insert into satis(adsoyad,telefon,barkodno,urunadi,miktari,satisfiyati,toplamfiyati,tarih) values(@adsoyad,@telefon,@barkodno,@urunadi,@miktari,@satisfiyati,@toplamfiyati,@tarih) ", baglanti);
				komut.Parameters.AddWithValue("@adsoyad", txtAdSoyad.Text);
				komut.Parameters.AddWithValue("@telefon", txtTelefon.Text);
				komut.Parameters.AddWithValue("@barkodno", dataGridView1.Rows[i].Cells["barkodno"].Value.ToString());
				komut.Parameters.AddWithValue("@urunadi", dataGridView1.Rows[i].Cells["urunadi"].Value.ToString());
				komut.Parameters.AddWithValue("@miktari", int.Parse(dataGridView1.Rows[i].Cells["miktari"].Value.ToString()));
				komut.Parameters.AddWithValue("@satisfiyati", double.Parse(dataGridView1.Rows[i].Cells["satisfiyati"].Value.ToString()));
				komut.Parameters.AddWithValue("@toplamfiyati", double.Parse(dataGridView1.Rows[i].Cells["toplamfiyati"].Value.ToString()));
				komut.Parameters.AddWithValue("@tarih", DateTime.Now.ToString());
				komut.ExecuteNonQuery();
				SqlCommand komut2 = new SqlCommand("update urun set miktari=miktari-'" + int.Parse(dataGridView1.Rows[i].Cells["miktari"].Value.ToString()) + "' where barkodno='" + dataGridView1.Rows[i].Cells["barkodno"].Value.ToString() + "'", baglanti);
				komut2.ExecuteNonQuery();
				
				baglanti.Close();

				MessageBox.Show("satış yapıldı");

			}
			baglanti.Open();
			SqlCommand komut3 = new SqlCommand("delete from sepet", baglanti);
			komut3.ExecuteNonQuery();
			baglanti.Close();
			daset.Tables["sepet"].Clear();
			sepetlistele();
			hesapla();
		}
	}
}

