﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stok
{
	public partial class frmMüşteriListele : Form
	{
		public frmMüşteriListele()
		{
			InitializeComponent();
		}
		SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-C1PR6G1\SQLEXPRESS;Initial Catalog=stokk_takipp;Integrated Security=True");

		DataSet daset = new DataSet();
		private void frmMüşteriListele_Load(object sender, EventArgs e)
		{
			Kayıt_Göster();

		}

		private void Kayıt_Göster()
		{
			baglanti.Open();
			SqlDataAdapter adtr = new SqlDataAdapter("select *from müşteri", baglanti); //müşteri tablosundaki butun kayıtları gostr
			adtr.Fill(daset, "müşteri"); //gecici tablo ve veritabanındaki tablo
			dataGridView1.DataSource = daset.Tables["müşteri"];
			baglanti.Close();
		}

		private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
			txtTelefon.Text = dataGridView1.CurrentRow.Cells["Telefon"].Value.ToString();
			txtAd.Text = dataGridView1.CurrentRow.Cells["Ad"].Value.ToString();
			txtSoyad.Text = dataGridView1.CurrentRow.Cells["Soyad"].Value.ToString();
			txtAdres.Text = dataGridView1.CurrentRow.Cells["Adres"].Value.ToString();
			txtEMail.Text = dataGridView1.CurrentRow.Cells["EMail"].Value.ToString();
			
		}

		private void btnGüncelle_Click(object sender, EventArgs e)
		{
			baglanti.Open();
			SqlCommand komut = new SqlCommand("update Müşteri set ad=@ad,soyad=@soyad, adres=@adres, email=@email where telefon=@telefon ", baglanti);
			komut.Parameters.AddWithValue("@ad", txtAd.Text);
			komut.Parameters.AddWithValue("@soyad", txtSoyad.Text);
			komut.Parameters.AddWithValue("@telefon", txtTelefon.Text);
			komut.Parameters.AddWithValue("@adres", txtAdres.Text);
			komut.Parameters.AddWithValue("@email", txtEMail.Text);
			komut.ExecuteNonQuery();
			baglanti.Close();
			daset.Tables["Müşteri"].Clear();//kaydı temizleme
			Kayıt_Göster();
			MessageBox.Show("Müşteri Kaydı Güncellendi");
			foreach (Control item in this.Controls)
			{
				if (item is TextBox)
				{
					item.Text = "";
				}
			}

		}

		private void btnSil_Click(object sender, EventArgs e)
		{
			baglanti.Open();
			SqlCommand komut = new SqlCommand("delete from Müşteri where telefon='" +dataGridView1.CurrentRow.Cells["telefon"].Value.ToString()+"'", baglanti);
			komut.ExecuteNonQuery();
			baglanti.Close();
			daset.Tables["Müşteri"].Clear();//kaydı temizleme
			Kayıt_Göster();
			MessageBox.Show("Kayıt Silindi");
		}

		private void txtTelArama_TextChanged(object sender, EventArgs e)
		{
			DataTable tablo = new DataTable();
			baglanti.Open();
			SqlDataAdapter adtr = new SqlDataAdapter("select *from Müşteri where telefon like '%"+txtTelArama.Text+"%'" ,baglanti);
			adtr.Fill(tablo);
			dataGridView1.DataSource = tablo;
			baglanti.Close();

		}
	}
}
