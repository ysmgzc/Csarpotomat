﻿
namespace stok
{
	partial class frmUrunEkle
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label7 = new System.Windows.Forms.Label();
			this.btnYeniEkle = new System.Windows.Forms.Button();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.comboMarka = new System.Windows.Forms.ComboBox();
			this.comboKategori = new System.Windows.Forms.ComboBox();
			this.txtSatisFiyati = new System.Windows.Forms.TextBox();
			this.txtAlisFiyati = new System.Windows.Forms.TextBox();
			this.txtMiktar = new System.Windows.Forms.TextBox();
			this.txtUrunAdi = new System.Windows.Forms.TextBox();
			this.txtBarkodNo = new System.Windows.Forms.TextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.lblMiktarı = new System.Windows.Forms.Label();
			this.SatisFiyatitxt = new System.Windows.Forms.TextBox();
			this.btnVarOlanaEkle = new System.Windows.Forms.Button();
			this.label14 = new System.Windows.Forms.Label();
			this.AlisFiyatitxt = new System.Windows.Forms.TextBox();
			this.label13 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.Urunaditxt = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.Miktaritxt = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.Kategoritxt = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.BarkodNotxt = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.Markatxt = new System.Windows.Forms.TextBox();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label7);
			this.groupBox1.Controls.Add(this.btnYeniEkle);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.comboMarka);
			this.groupBox1.Controls.Add(this.comboKategori);
			this.groupBox1.Controls.Add(this.txtSatisFiyati);
			this.groupBox1.Controls.Add(this.txtAlisFiyati);
			this.groupBox1.Controls.Add(this.txtMiktar);
			this.groupBox1.Controls.Add(this.txtUrunAdi);
			this.groupBox1.Controls.Add(this.txtBarkodNo);
			this.groupBox1.Location = new System.Drawing.Point(29, 30);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(284, 334);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Yeni Ürün";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(53, 235);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(57, 13);
			this.label7.TabIndex = 9;
			this.label7.Text = "Satış Fiyatı";
			// 
			// btnYeniEkle
			// 
			this.btnYeniEkle.Location = new System.Drawing.Point(159, 276);
			this.btnYeniEkle.Name = "btnYeniEkle";
			this.btnYeniEkle.Size = new System.Drawing.Size(75, 40);
			this.btnYeniEkle.TabIndex = 2;
			this.btnYeniEkle.Text = "EKLE";
			this.btnYeniEkle.UseVisualStyleBackColor = true;
			this.btnYeniEkle.Click += new System.EventHandler(this.btnYeniEkle_Click);
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(53, 202);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(50, 13);
			this.label6.TabIndex = 8;
			this.label6.Text = "Alış Fiyatı";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(53, 169);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(38, 13);
			this.label5.TabIndex = 7;
			this.label5.Text = "Miktarı";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(53, 136);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(48, 13);
			this.label4.TabIndex = 6;
			this.label4.Text = "Ürün Adı";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(53, 103);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(37, 13);
			this.label3.TabIndex = 5;
			this.label3.Text = "Marka";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(53, 69);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(46, 13);
			this.label2.TabIndex = 4;
			this.label2.Text = "Kategori";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(53, 35);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(58, 13);
			this.label1.TabIndex = 3;
			this.label1.Text = "Barkod No";
			// 
			// comboMarka
			// 
			this.comboMarka.FormattingEnabled = true;
			this.comboMarka.Location = new System.Drawing.Point(145, 95);
			this.comboMarka.Name = "comboMarka";
			this.comboMarka.Size = new System.Drawing.Size(100, 21);
			this.comboMarka.TabIndex = 2;
			this.comboMarka.SelectedIndexChanged += new System.EventHandler(this.comboMarka_SelectedIndexChanged);
			// 
			// comboKategori
			// 
			this.comboKategori.FormattingEnabled = true;
			this.comboKategori.Location = new System.Drawing.Point(145, 61);
			this.comboKategori.Name = "comboKategori";
			this.comboKategori.Size = new System.Drawing.Size(100, 21);
			this.comboKategori.TabIndex = 2;
			this.comboKategori.SelectedIndexChanged += new System.EventHandler(this.comboKategori_SelectedIndexChanged);
			// 
			// txtSatisFiyati
			// 
			this.txtSatisFiyati.Location = new System.Drawing.Point(145, 228);
			this.txtSatisFiyati.Name = "txtSatisFiyati";
			this.txtSatisFiyati.Size = new System.Drawing.Size(100, 20);
			this.txtSatisFiyati.TabIndex = 1;
			// 
			// txtAlisFiyati
			// 
			this.txtAlisFiyati.Location = new System.Drawing.Point(145, 195);
			this.txtAlisFiyati.Name = "txtAlisFiyati";
			this.txtAlisFiyati.Size = new System.Drawing.Size(100, 20);
			this.txtAlisFiyati.TabIndex = 1;
			// 
			// txtMiktar
			// 
			this.txtMiktar.Location = new System.Drawing.Point(145, 162);
			this.txtMiktar.Name = "txtMiktar";
			this.txtMiktar.Size = new System.Drawing.Size(100, 20);
			this.txtMiktar.TabIndex = 1;
			// 
			// txtUrunAdi
			// 
			this.txtUrunAdi.Location = new System.Drawing.Point(145, 129);
			this.txtUrunAdi.Name = "txtUrunAdi";
			this.txtUrunAdi.Size = new System.Drawing.Size(100, 20);
			this.txtUrunAdi.TabIndex = 1;
			// 
			// txtBarkodNo
			// 
			this.txtBarkodNo.Location = new System.Drawing.Point(145, 28);
			this.txtBarkodNo.Name = "txtBarkodNo";
			this.txtBarkodNo.Size = new System.Drawing.Size(100, 20);
			this.txtBarkodNo.TabIndex = 0;
			this.txtBarkodNo.TextChanged += new System.EventHandler(this.txtBarkodNo_TextChanged);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.lblMiktarı);
			this.groupBox2.Controls.Add(this.SatisFiyatitxt);
			this.groupBox2.Controls.Add(this.btnVarOlanaEkle);
			this.groupBox2.Controls.Add(this.label14);
			this.groupBox2.Controls.Add(this.AlisFiyatitxt);
			this.groupBox2.Controls.Add(this.label13);
			this.groupBox2.Controls.Add(this.label12);
			this.groupBox2.Controls.Add(this.Urunaditxt);
			this.groupBox2.Controls.Add(this.label11);
			this.groupBox2.Controls.Add(this.Miktaritxt);
			this.groupBox2.Controls.Add(this.label10);
			this.groupBox2.Controls.Add(this.Kategoritxt);
			this.groupBox2.Controls.Add(this.label9);
			this.groupBox2.Controls.Add(this.BarkodNotxt);
			this.groupBox2.Controls.Add(this.label8);
			this.groupBox2.Controls.Add(this.Markatxt);
			this.groupBox2.Location = new System.Drawing.Point(352, 30);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(292, 334);
			this.groupBox2.TabIndex = 1;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Var Olan Ürün";
			// 
			// lblMiktarı
			// 
			this.lblMiktarı.AutoSize = true;
			this.lblMiktarı.Location = new System.Drawing.Point(15, 289);
			this.lblMiktarı.Name = "lblMiktarı";
			this.lblMiktarı.Size = new System.Drawing.Size(0, 13);
			this.lblMiktarı.TabIndex = 11;
			// 
			// SatisFiyatitxt
			// 
			this.SatisFiyatitxt.Location = new System.Drawing.Point(169, 228);
			this.SatisFiyatitxt.Name = "SatisFiyatitxt";
			this.SatisFiyatitxt.Size = new System.Drawing.Size(100, 20);
			this.SatisFiyatitxt.TabIndex = 10;
			// 
			// btnVarOlanaEkle
			// 
			this.btnVarOlanaEkle.Location = new System.Drawing.Point(183, 276);
			this.btnVarOlanaEkle.Name = "btnVarOlanaEkle";
			this.btnVarOlanaEkle.Size = new System.Drawing.Size(75, 40);
			this.btnVarOlanaEkle.TabIndex = 3;
			this.btnVarOlanaEkle.Text = "EKLE";
			this.btnVarOlanaEkle.UseVisualStyleBackColor = true;
			this.btnVarOlanaEkle.Click += new System.EventHandler(this.btnVarOlanaEkle_Click);
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(57, 235);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(57, 13);
			this.label14.TabIndex = 9;
			this.label14.Text = "Satış Fiyatı";
			// 
			// AlisFiyatitxt
			// 
			this.AlisFiyatitxt.Location = new System.Drawing.Point(169, 195);
			this.AlisFiyatitxt.Name = "AlisFiyatitxt";
			this.AlisFiyatitxt.Size = new System.Drawing.Size(100, 20);
			this.AlisFiyatitxt.TabIndex = 1;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(57, 202);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(50, 13);
			this.label13.TabIndex = 8;
			this.label13.Text = "Alış Fiyatı";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(57, 169);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(38, 13);
			this.label12.TabIndex = 7;
			this.label12.Text = "Miktarı";
			// 
			// Urunaditxt
			// 
			this.Urunaditxt.Location = new System.Drawing.Point(169, 129);
			this.Urunaditxt.Name = "Urunaditxt";
			this.Urunaditxt.Size = new System.Drawing.Size(100, 20);
			this.Urunaditxt.TabIndex = 1;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(57, 136);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(48, 13);
			this.label11.TabIndex = 6;
			this.label11.Text = "Ürün Adı";
			// 
			// Miktaritxt
			// 
			this.Miktaritxt.Location = new System.Drawing.Point(169, 162);
			this.Miktaritxt.Name = "Miktaritxt";
			this.Miktaritxt.Size = new System.Drawing.Size(100, 20);
			this.Miktaritxt.TabIndex = 1;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(57, 103);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(37, 13);
			this.label10.TabIndex = 5;
			this.label10.Text = "Marka";
			// 
			// Kategoritxt
			// 
			this.Kategoritxt.Location = new System.Drawing.Point(169, 66);
			this.Kategoritxt.Name = "Kategoritxt";
			this.Kategoritxt.Size = new System.Drawing.Size(100, 20);
			this.Kategoritxt.TabIndex = 0;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(57, 69);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(46, 13);
			this.label9.TabIndex = 4;
			this.label9.Text = "Kategori";
			// 
			// BarkodNotxt
			// 
			this.BarkodNotxt.Location = new System.Drawing.Point(169, 32);
			this.BarkodNotxt.Name = "BarkodNotxt";
			this.BarkodNotxt.Size = new System.Drawing.Size(100, 20);
			this.BarkodNotxt.TabIndex = 0;
			this.BarkodNotxt.TextChanged += new System.EventHandler(this.BarkodNotxt_TextChanged);
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(57, 35);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(58, 13);
			this.label8.TabIndex = 3;
			this.label8.Text = "Barkod No";
			// 
			// Markatxt
			// 
			this.Markatxt.Location = new System.Drawing.Point(169, 96);
			this.Markatxt.Name = "Markatxt";
			this.Markatxt.Size = new System.Drawing.Size(100, 20);
			this.Markatxt.TabIndex = 1;
			// 
			// frmUrunEkle
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Yellow;
			this.ClientSize = new System.Drawing.Size(670, 391);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Name = "frmUrunEkle";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Ürün Ekleme Sayfası";
			this.Load += new System.EventHandler(this.frmUrunEkle_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox txtSatisFiyati;
		private System.Windows.Forms.TextBox txtAlisFiyati;
		private System.Windows.Forms.TextBox txtMiktar;
		private System.Windows.Forms.TextBox txtUrunAdi;
		private System.Windows.Forms.TextBox txtBarkodNo;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.TextBox AlisFiyatitxt;
		private System.Windows.Forms.TextBox Urunaditxt;
		private System.Windows.Forms.TextBox Miktaritxt;
		private System.Windows.Forms.TextBox Kategoritxt;
		private System.Windows.Forms.TextBox BarkodNotxt;
		private System.Windows.Forms.TextBox Markatxt;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Button btnYeniEkle;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox comboMarka;
		private System.Windows.Forms.ComboBox comboKategori;
		private System.Windows.Forms.Button btnVarOlanaEkle;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox SatisFiyatitxt;
		private System.Windows.Forms.Label lblMiktarı;
	}
}