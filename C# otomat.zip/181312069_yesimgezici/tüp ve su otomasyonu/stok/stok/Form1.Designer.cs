﻿
namespace stok
{
	partial class SatısSayfası
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.txtTelefon = new System.Windows.Forms.TextBox();
			this.txtAdSoyad = new System.Windows.Forms.TextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.lblBarkodNo = new System.Windows.Forms.Label();
			this.txtToplamFiyat = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txtSatisFiyati = new System.Windows.Forms.TextBox();
			this.txtUrunMiktari = new System.Windows.Forms.TextBox();
			this.txtBarkodNo = new System.Windows.Forms.TextBox();
			this.txtUrunAdı = new System.Windows.Forms.TextBox();
			this.btnEkle = new System.Windows.Forms.Button();
			this.btnSil = new System.Windows.Forms.Button();
			this.btnSatisİptal = new System.Windows.Forms.Button();
			this.btnSatisYap = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.button2 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.btnSatislariListele = new System.Windows.Forms.Button();
			this.btnUrunListele = new System.Windows.Forms.Button();
			this.btnUrunEkle = new System.Windows.Forms.Button();
			this.btnMusteriListele = new System.Windows.Forms.Button();
			this.btnMusteriEkle = new System.Windows.Forms.Button();
			this.lblGenelToplam = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// dataGridView1
			// 
			this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Location = new System.Drawing.Point(237, 137);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.RowHeadersWidth = 42;
			this.dataGridView1.Size = new System.Drawing.Size(431, 240);
			this.dataGridView1.TabIndex = 0;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.txtTelefon);
			this.groupBox1.Controls.Add(this.txtAdSoyad);
			this.groupBox1.Location = new System.Drawing.Point(9, 137);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(200, 100);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Müşteri İşlemleri";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(6, 73);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(43, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "Telefon";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 27);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(53, 13);
			this.label1.TabIndex = 2;
			this.label1.Text = "Ad Soyad";
			// 
			// txtTelefon
			// 
			this.txtTelefon.Location = new System.Drawing.Point(90, 70);
			this.txtTelefon.Name = "txtTelefon";
			this.txtTelefon.Size = new System.Drawing.Size(100, 20);
			this.txtTelefon.TabIndex = 1;
			this.txtTelefon.TextChanged += new System.EventHandler(this.txtTelefon_TextChanged);
			// 
			// txtAdSoyad
			// 
			this.txtAdSoyad.Location = new System.Drawing.Point(89, 24);
			this.txtAdSoyad.Name = "txtAdSoyad";
			this.txtAdSoyad.Size = new System.Drawing.Size(100, 20);
			this.txtAdSoyad.TabIndex = 0;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.lblBarkodNo);
			this.groupBox2.Controls.Add(this.txtToplamFiyat);
			this.groupBox2.Controls.Add(this.label6);
			this.groupBox2.Controls.Add(this.label5);
			this.groupBox2.Controls.Add(this.label3);
			this.groupBox2.Controls.Add(this.label4);
			this.groupBox2.Controls.Add(this.txtSatisFiyati);
			this.groupBox2.Controls.Add(this.txtUrunMiktari);
			this.groupBox2.Controls.Add(this.txtBarkodNo);
			this.groupBox2.Controls.Add(this.txtUrunAdı);
			this.groupBox2.Location = new System.Drawing.Point(9, 247);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(200, 192);
			this.groupBox2.TabIndex = 2;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Ürün İşlemleri";
			// 
			// lblBarkodNo
			// 
			this.lblBarkodNo.AutoSize = true;
			this.lblBarkodNo.Location = new System.Drawing.Point(6, 26);
			this.lblBarkodNo.Name = "lblBarkodNo";
			this.lblBarkodNo.Size = new System.Drawing.Size(58, 13);
			this.lblBarkodNo.TabIndex = 4;
			this.lblBarkodNo.Text = "Barkod No";
			// 
			// txtToplamFiyat
			// 
			this.txtToplamFiyat.Location = new System.Drawing.Point(90, 155);
			this.txtToplamFiyat.Name = "txtToplamFiyat";
			this.txtToplamFiyat.Size = new System.Drawing.Size(100, 20);
			this.txtToplamFiyat.TabIndex = 3;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(6, 162);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(69, 13);
			this.label6.TabIndex = 2;
			this.label6.Text = "Toplam Fiyatı";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(6, 128);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(57, 13);
			this.label5.TabIndex = 2;
			this.label5.Text = "Satış Fiyatı";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(6, 94);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(38, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "Miktarı";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(6, 60);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(48, 13);
			this.label4.TabIndex = 2;
			this.label4.Text = "Ürün Adı";
			// 
			// txtSatisFiyati
			// 
			this.txtSatisFiyati.Location = new System.Drawing.Point(90, 121);
			this.txtSatisFiyati.Name = "txtSatisFiyati";
			this.txtSatisFiyati.Size = new System.Drawing.Size(100, 20);
			this.txtSatisFiyati.TabIndex = 2;
			this.txtSatisFiyati.TextChanged += new System.EventHandler(this.txtSatisFiyati_TextChanged);
			// 
			// txtUrunMiktari
			// 
			this.txtUrunMiktari.Location = new System.Drawing.Point(90, 87);
			this.txtUrunMiktari.Name = "txtUrunMiktari";
			this.txtUrunMiktari.Size = new System.Drawing.Size(100, 20);
			this.txtUrunMiktari.TabIndex = 1;
			this.txtUrunMiktari.TextChanged += new System.EventHandler(this.txtUrunMiktari_TextChanged);
			// 
			// txtBarkodNo
			// 
			this.txtBarkodNo.Location = new System.Drawing.Point(90, 19);
			this.txtBarkodNo.Name = "txtBarkodNo";
			this.txtBarkodNo.Size = new System.Drawing.Size(100, 20);
			this.txtBarkodNo.TabIndex = 0;
			this.txtBarkodNo.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
			// 
			// txtUrunAdı
			// 
			this.txtUrunAdı.Location = new System.Drawing.Point(90, 53);
			this.txtUrunAdı.Name = "txtUrunAdı";
			this.txtUrunAdı.Size = new System.Drawing.Size(100, 20);
			this.txtUrunAdı.TabIndex = 0;
			// 
			// btnEkle
			// 
			this.btnEkle.Location = new System.Drawing.Point(237, 393);
			this.btnEkle.Name = "btnEkle";
			this.btnEkle.Size = new System.Drawing.Size(75, 46);
			this.btnEkle.TabIndex = 3;
			this.btnEkle.Text = "Ekle";
			this.btnEkle.UseVisualStyleBackColor = true;
			this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
			// 
			// btnSil
			// 
			this.btnSil.Location = new System.Drawing.Point(674, 135);
			this.btnSil.Name = "btnSil";
			this.btnSil.Size = new System.Drawing.Size(75, 46);
			this.btnSil.TabIndex = 3;
			this.btnSil.Text = "Sil";
			this.btnSil.UseVisualStyleBackColor = true;
			this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
			// 
			// btnSatisİptal
			// 
			this.btnSatisİptal.Location = new System.Drawing.Point(674, 191);
			this.btnSatisİptal.Name = "btnSatisİptal";
			this.btnSatisİptal.Size = new System.Drawing.Size(75, 46);
			this.btnSatisİptal.TabIndex = 3;
			this.btnSatisİptal.Text = "Satış İptal";
			this.btnSatisİptal.UseVisualStyleBackColor = true;
			this.btnSatisİptal.Click += new System.EventHandler(this.btnSatisİptal_Click);
			// 
			// btnSatisYap
			// 
			this.btnSatisYap.Location = new System.Drawing.Point(593, 393);
			this.btnSatisYap.Name = "btnSatisYap";
			this.btnSatisYap.Size = new System.Drawing.Size(75, 46);
			this.btnSatisYap.TabIndex = 3;
			this.btnSatisYap.Text = "Satış Yap";
			this.btnSatisYap.UseVisualStyleBackColor = true;
			this.btnSatisYap.Click += new System.EventHandler(this.btnSatisYap_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.button2);
			this.panel1.Controls.Add(this.button1);
			this.panel1.Controls.Add(this.btnSatislariListele);
			this.panel1.Controls.Add(this.btnUrunListele);
			this.panel1.Controls.Add(this.btnUrunEkle);
			this.panel1.Controls.Add(this.btnMusteriListele);
			this.panel1.Controls.Add(this.btnMusteriEkle);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(755, 100);
			this.panel1.TabIndex = 4;
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(318, 34);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(95, 39);
			this.button2.TabIndex = 0;
			this.button2.Text = "Marka";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(217, 34);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(95, 39);
			this.button1.TabIndex = 0;
			this.button1.Text = "Kategori";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// btnSatislariListele
			// 
			this.btnSatislariListele.Location = new System.Drawing.Point(654, 34);
			this.btnSatislariListele.Name = "btnSatislariListele";
			this.btnSatislariListele.Size = new System.Drawing.Size(95, 39);
			this.btnSatislariListele.TabIndex = 0;
			this.btnSatislariListele.Text = "Satışları Listele";
			this.btnSatislariListele.UseVisualStyleBackColor = true;
			this.btnSatislariListele.Click += new System.EventHandler(this.btnSatislariListele_Click);
			// 
			// btnUrunListele
			// 
			this.btnUrunListele.Location = new System.Drawing.Point(529, 34);
			this.btnUrunListele.Name = "btnUrunListele";
			this.btnUrunListele.Size = new System.Drawing.Size(95, 39);
			this.btnUrunListele.TabIndex = 0;
			this.btnUrunListele.Text = "Ürün Listele";
			this.btnUrunListele.UseVisualStyleBackColor = true;
			this.btnUrunListele.Click += new System.EventHandler(this.btnUrunListele_Click);
			// 
			// btnUrunEkle
			// 
			this.btnUrunEkle.Location = new System.Drawing.Point(428, 34);
			this.btnUrunEkle.Name = "btnUrunEkle";
			this.btnUrunEkle.Size = new System.Drawing.Size(95, 39);
			this.btnUrunEkle.TabIndex = 0;
			this.btnUrunEkle.Text = "Ürün Ekle";
			this.btnUrunEkle.UseVisualStyleBackColor = true;
			this.btnUrunEkle.Click += new System.EventHandler(this.btnUrunEkle_Click);
			// 
			// btnMusteriListele
			// 
			this.btnMusteriListele.Location = new System.Drawing.Point(108, 34);
			this.btnMusteriListele.Name = "btnMusteriListele";
			this.btnMusteriListele.Size = new System.Drawing.Size(95, 39);
			this.btnMusteriListele.TabIndex = 0;
			this.btnMusteriListele.Text = "Müşteri Listele";
			this.btnMusteriListele.UseVisualStyleBackColor = true;
			this.btnMusteriListele.Click += new System.EventHandler(this.btnMusteriListele_Click);
			// 
			// btnMusteriEkle
			// 
			this.btnMusteriEkle.Location = new System.Drawing.Point(7, 34);
			this.btnMusteriEkle.Name = "btnMusteriEkle";
			this.btnMusteriEkle.Size = new System.Drawing.Size(95, 39);
			this.btnMusteriEkle.TabIndex = 0;
			this.btnMusteriEkle.Text = "Müşteri Ekle";
			this.btnMusteriEkle.UseVisualStyleBackColor = true;
			this.btnMusteriEkle.Click += new System.EventHandler(this.btnMusteriEkle_Click);
			// 
			// lblGenelToplam
			// 
			this.lblGenelToplam.AutoSize = true;
			this.lblGenelToplam.Location = new System.Drawing.Point(425, 416);
			this.lblGenelToplam.Name = "lblGenelToplam";
			this.lblGenelToplam.Size = new System.Drawing.Size(73, 13);
			this.lblGenelToplam.TabIndex = 5;
			this.lblGenelToplam.Text = "Genel Toplam";
			// 
			// SatısSayfası
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Yellow;
			this.ClientSize = new System.Drawing.Size(755, 482);
			this.Controls.Add(this.lblGenelToplam);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.btnSatisYap);
			this.Controls.Add(this.btnSatisİptal);
			this.Controls.Add(this.btnSil);
			this.Controls.Add(this.btnEkle);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.dataGridView1);
			this.Name = "SatısSayfası";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Satış Sayfası";
			this.Load += new System.EventHandler(this.SatısSayfası_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtTelefon;
		private System.Windows.Forms.TextBox txtAdSoyad;
		private System.Windows.Forms.TextBox txtToplamFiyat;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtSatisFiyati;
		private System.Windows.Forms.TextBox txtUrunMiktari;
		private System.Windows.Forms.TextBox txtUrunAdı;
		private System.Windows.Forms.Button btnEkle;
		private System.Windows.Forms.Button btnSil;
		private System.Windows.Forms.Button btnSatisİptal;
		private System.Windows.Forms.Button btnSatisYap;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btnSatislariListele;
		private System.Windows.Forms.Button btnUrunListele;
		private System.Windows.Forms.Button btnUrunEkle;
		private System.Windows.Forms.Button btnMusteriListele;
		private System.Windows.Forms.Button btnMusteriEkle;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label lblBarkodNo;
		private System.Windows.Forms.TextBox txtBarkodNo;
		private System.Windows.Forms.Label lblGenelToplam;
	}
}

